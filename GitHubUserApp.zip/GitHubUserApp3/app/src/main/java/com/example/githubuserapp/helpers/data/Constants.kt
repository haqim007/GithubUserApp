package com.example.githubuserapp.helpers.data

object Constants {
    const val BASEURL = "https://api.github.com/"
    const val HEADER_ACCEPT = "application/vnd.github.v3+json"

}